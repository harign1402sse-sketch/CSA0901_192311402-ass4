import javax.swing.*;
import java.awt.*;

public class LibrarySearch extends JFrame {
    private final JTextField search = new JTextField(22);
    private final JComboBox<String> category = new JComboBox<>(new String[]{"All", "Books", "Journals", "Theses"});
    private final DefaultListModel<String> results = new DefaultListModel<>();
    private final JLabel status = new JLabel("Enter a title or keyword");
    public LibrarySearch() {
        super("Campus Library Search"); setLayout(new BorderLayout(8,8));
        JLabel title = new JLabel("Campus Library", SwingConstants.CENTER); title.setFont(title.getFont().deriveFont(Font.BOLD,20f)); add(title,BorderLayout.NORTH);
        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchRow.add(search); searchRow.add(category); JButton find = new JButton("Search"); searchRow.add(find);
        JPanel center = new JPanel(new BorderLayout()); center.add(searchRow,BorderLayout.NORTH);
        JList<String> list = new JList<>(results); center.add(new JScrollPane(list),BorderLayout.CENTER); add(center,BorderLayout.CENTER);
        JPanel bottom = new JPanel(new BorderLayout()); JPanel actions = new JPanel(new FlowLayout());
        JButton prev = new JButton("Prev"), next = new JButton("Next"), reserve = new JButton("Reserve");
        actions.add(prev); actions.add(next); actions.add(reserve); bottom.add(actions,BorderLayout.NORTH); bottom.add(status,BorderLayout.SOUTH); add(bottom,BorderLayout.SOUTH);
        find.addActionListener(e -> { results.clear(); String q=search.getText().trim(); if(q.isEmpty()) status.setText("Enter a search term"); else { results.addElement("Sample result for: "+q); status.setText("1 result shown (demo data)"); }});
        prev.addActionListener(e -> status.setText("Previous page")); next.addActionListener(e -> status.setText("Next page"));
        reserve.addActionListener(e -> { String selected=list.getSelectedValue(); status.setText(selected==null?"Select a result first":"Reservation requested: "+selected); });
        setDefaultCloseOperation(EXIT_ON_CLOSE); setMinimumSize(new Dimension(520,350)); setSize(720,480); setLocationRelativeTo(null);
    }
    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new LibrarySearch().setVisible(true)); }
}
