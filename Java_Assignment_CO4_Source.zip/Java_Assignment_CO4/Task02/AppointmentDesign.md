# Task 2 – Appointment Desk
This task is design-only in the source-code submission list. Event table, containment hierarchy, handler pseudocode and event trace are provided in the assignment answers.
