# Programming in Java – Assignment 4 (CO4)

**Student:** Dinnepati Sindhu Prasad (edit if needed)  
**Register number:** ADD YOUR REGISTER NUMBER  
**Course:** CSA09 – Programming in Java  
**Java:** JDK 17 or later (tested with the installed JDK in this environment)

## Structure
- `Task01/FeeWindow.java` – fee payment UI, validation/service separation, JDBC prepared statement and SwingWorker.
- `Task02/AppointmentDesign.md` – design artefact; Task 2 asks for event model, hierarchy, pseudocode and trace rather than a required implementation.
- `Task03/LibrarySearch.java` – nested Swing layout with resizable results region.
- `Task04/DrawPad.java` – completed mouse listener TODOs and persistent repainting.
- `Task05/FrameListener/Converter.java` – frame implements ActionListener.
- `Task05/NamedInner/Converter.java` – named inner listener.
- `Task05/AnonymousInner/Converter.java` – anonymous listener.
- `Task05/Lambda/Converter.java` – lambda listener registered for button and Enter key.
- `Task06/EventRegistrationApp.java` – Swing UI with asynchronous DB work, filtering, paging and CSV export.
- `Task06/RegistrationService.java` – validation and registration business rules.
- `Task06/RegistrationDAO.java` – JDBC data-access layer.
- `Task06/schema.sql` – MySQL schema with unique student/event constraint.

## Compile and run
Compile each standalone task from its own folder:

```bash
cd Task03
javac LibrarySearch.java
java LibrarySearch
```

For AWT DrawPad:

```bash
cd Task04
javac DrawPad.java
java DrawPad
```

For each Task05 version, enter its folder and run:

```bash
javac Converter.java
java Converter
```

Task01 and Task06 compile with the JDK because they use only standard Java/JDBC APIs:

```bash
cd Task01
javac FeeWindow.java
java FeeWindow
```

```bash
cd Task06
javac EventRegistrationApp.java
java EventRegistrationApp
```

## Database configuration
Task01 and Task06 require a running MySQL server and the MySQL Connector/J driver at runtime. Add the Connector/J JAR to the classpath. Create the schema using `Task06/schema.sql`. Set environment variables:

- Task01: `FEE_DB_URL`, `FEE_DB_USER`, `FEE_DB_PASSWORD`; create a `fees(reg_no, amount, paid_at)` table.
- Task06: `EVENT_DB_URL`, `EVENT_DB_USER`, `EVENT_DB_PASSWORD`.

Example Windows PowerShell:

```powershell
$env:EVENT_DB_URL="jdbc:mysql://localhost:3306/campus_events"
$env:EVENT_DB_USER="root"
$env:EVENT_DB_PASSWORD="your-password"
java -cp ".;mysql-connector-j-<version>.jar" EventRegistrationApp
```

For Task01 create the table:

```sql
CREATE TABLE fees (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  reg_no VARCHAR(30) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Expected behaviour / evidence to collect
- Task01: valid positive fee is inserted; blank/invalid/non-positive inputs are rejected. Verify database connection and insert on your MySQL installation.
- Task02: follow the event table and handler pseudocode in the written answers.
- Task03: resize the window; centre results list expands while search/actions remain in their own bands. Capture three sizes.
- Task04: click several positions; click count increments and dots remain after minimise/restore. Capture before/after screenshots.
- Task05: each of four programs converts INR to USD (rate 0.012) or EUR (rate 0.011); button and Enter invoke same action; invalid input displays an error dialog.
- Task06: run schema.sql, configure Connector/J and environment variables. Test a new registration, blank fields, duplicate student/event registration, filter, next/previous page and CSV export.

## Important submission notes
The database tasks cannot be fully demonstrated without your local MySQL server, credentials and Connector/J JAR. Do not claim database execution until you run these tests locally. Add your own screenshots, actual Java version, register number and GitHub URL. Commit each task separately as required by the question paper.
