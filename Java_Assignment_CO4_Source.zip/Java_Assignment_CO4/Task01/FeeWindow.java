import javax.swing.*;
import java.awt.*;
import java.sql.*;

class FeeService {
    private final String url, user, password;
    FeeService(String url, String user, String password) {
        this.url = url; this.user = user; this.password = password;
    }
    String pay(String regNo, double amount) throws SQLException {
        if (regNo == null || regNo.isBlank()) throw new IllegalArgumentException("Registration number is required");
        if (!Double.isFinite(amount) || amount <= 0) throw new IllegalArgumentException("Amount must be positive");
        String sql = "INSERT INTO fees(reg_no, amount, paid_at) VALUES(?, ?, CURRENT_TIMESTAMP)";
        try (Connection c = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, regNo); ps.setDouble(2, amount); ps.executeUpdate();
        }
        return "Payment recorded successfully for " + regNo;
    }
}

public class FeeWindow extends JFrame {
    private final JTextField regNo = new JTextField(14), amount = new JTextField(10);
    private final FeeService service = new FeeService(
        System.getenv().getOrDefault("FEE_DB_URL", "jdbc:mysql://localhost:3306/college"),
        System.getenv().getOrDefault("FEE_DB_USER", "root"),
        System.getenv().getOrDefault("FEE_DB_PASSWORD", ""));
    public FeeWindow() {
        super("Student Fee Payment"); setLayout(new BorderLayout(8,8));
        JPanel form = new JPanel(new GridLayout(2,2,6,6));
        form.add(new JLabel("Registration number")); form.add(regNo);
        form.add(new JLabel("Amount (INR)")); form.add(amount); add(form, BorderLayout.CENTER);
        JPanel buttons = new JPanel(new FlowLayout());
        JButton pay = new JButton("Pay"), clear = new JButton("Clear"), receipt = new JButton("Receipt");
        buttons.add(pay); buttons.add(clear); buttons.add(receipt); add(buttons, BorderLayout.SOUTH);
        pay.addActionListener(e -> doPayment());
        clear.addActionListener(e -> { regNo.setText(""); amount.setText(""); });
        receipt.addActionListener(e -> JOptionPane.showMessageDialog(this, "Use the registration number to retrieve the payment receipt."));
        setDefaultCloseOperation(DISPOSE_ON_CLOSE); setSize(420,180); setLocationRelativeTo(null);
    }
    private void doPayment() {
        final String id = regNo.getText().trim(); final double value;
        try { value = Double.parseDouble(amount.getText().trim()); }
        catch (NumberFormatException ex) { JOptionPane.showMessageDialog(this,"Enter a valid amount"); return; }
        JButton source = null;
        new SwingWorker<String,Void>() {
            protected String doInBackground() throws Exception { return service.pay(id,value); }
            protected void done() { try { JOptionPane.showMessageDialog(FeeWindow.this,get()); }
                catch (Exception ex) { JOptionPane.showMessageDialog(FeeWindow.this,"Payment failed: "+ex.getCause().getMessage()); } }
        }.execute();
    }
    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new FeeWindow().setVisible(true)); }
}
