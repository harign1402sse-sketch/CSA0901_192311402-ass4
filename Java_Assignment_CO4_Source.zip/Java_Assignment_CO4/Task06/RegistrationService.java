import java.sql.*; import java.util.*;
public class RegistrationService {
 private final RegistrationDAO dao;
 public RegistrationService(RegistrationDAO dao){this.dao=dao;}
 public void register(String sid,String name,String event)throws Exception{
  if(sid==null||sid.isBlank()||name==null||name.isBlank()||event==null||event.isBlank())throw new IllegalArgumentException("Student ID, name and event are required");
  try{dao.insert(sid.trim(),name.trim(),event);}catch(SQLIntegrityConstraintViolationException ex){throw new IllegalStateException("This student is already registered for this event",ex);}
 }
 public List<Object[]> page(String event,int limit,int offset)throws SQLException{return dao.findPage(event,limit,offset);}
}
