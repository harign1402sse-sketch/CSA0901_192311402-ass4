import java.sql.*; import java.util.*;
public class RegistrationDAO {
 private final String url,user,password;
 public RegistrationDAO(String url,String user,String password){this.url=url;this.user=user;this.password=password;}
 public void insert(String sid,String name,String event)throws SQLException{
  String sql="INSERT INTO registrations(student_id,student_name,event_name) VALUES(?,?,?)";
  try(Connection c=DriverManager.getConnection(url,user,password);PreparedStatement p=c.prepareStatement(sql)){p.setString(1,sid);p.setString(2,name);p.setString(3,event);p.executeUpdate();}
 }
 public List<Object[]> findPage(String event,int limit,int offset)throws SQLException{
  String sql="SELECT id,student_id,student_name,event_name,registered_at FROM registrations "+(event.equals("All")?"":"WHERE event_name=? ")+"ORDER BY id LIMIT ? OFFSET ?";
  List<Object[]> rows=new ArrayList<>();try(Connection c=DriverManager.getConnection(url,user,password);PreparedStatement p=c.prepareStatement(sql)){int i=1;if(!event.equals("All"))p.setString(i++,event);p.setInt(i++,limit);p.setInt(i,offset);try(ResultSet rs=p.executeQuery()){while(rs.next())rows.add(new Object[]{rs.getLong(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getTimestamp(5)});}}return rows;
 }
}
