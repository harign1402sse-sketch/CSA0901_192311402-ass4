import javax.swing.*; import java.awt.*; import java.awt.event.*;
public class Converter extends JFrame implements ActionListener {
 private final JTextField amount=new JTextField(10); private final JComboBox<String> target=new JComboBox<>(new String[]{"USD","EUR"}); private final JLabel result=new JLabel(" ");
 public Converter(){super("Converter – Frame Listener");setLayout(new FlowLayout());JButton b=new JButton("Convert");add(new JLabel("INR"));add(amount);add(target);add(b);add(result);b.addActionListener(this);amount.addActionListener(this);addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){dispose();}});setDefaultCloseOperation(DISPOSE_ON_CLOSE);pack();}
 public void actionPerformed(ActionEvent e){convert();} private void convert(){try{double v=Double.parseDouble(amount.getText().trim());if(v<0)throw new NumberFormatException();String out=String.format("%.2f %s",v*(target.getSelectedItem().equals("USD")?.012:.011),target.getSelectedItem());result.setText(out);JOptionPane.showMessageDialog(this,out);}catch(NumberFormatException ex){result.setText("Invalid amount");JOptionPane.showMessageDialog(this,"Invalid amount","Error",JOptionPane.ERROR_MESSAGE);}}
 public static void main(String[]x){SwingUtilities.invokeLater(()->new Converter().setVisible(true));}
}
