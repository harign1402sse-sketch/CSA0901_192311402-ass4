import java.awt.FlowLayout; import java.awt.event.*; import javax.swing.*;
public class Converter extends JFrame {
 private final JTextField amount=new JTextField(10); private final JComboBox<String> target=new JComboBox<>(new String[]{"USD","EUR"}); private final JLabel result=new JLabel(" ");
 private static double rate(String c){return c.equals("USD")?.012:.011;}
 public Converter(){super("Currency Converter");setLayout(new FlowLayout());JButton b=new JButton("Convert");add(new JLabel("INR"));add(amount);add(target);add(b);add(result);ActionListener convert=e->convert();b.addActionListener(convert);amount.addActionListener(convert);addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){dispose();}});setDefaultCloseOperation(DISPOSE_ON_CLOSE);pack();}
 private void convert(){try{double v=Double.parseDouble(amount.getText().trim());if(!Double.isFinite(v)||v<0)throw new NumberFormatException();String c=(String)target.getSelectedItem();String out=String.format("%.2f %s",v*rate(c),c);result.setText(out);JOptionPane.showMessageDialog(this,out);}catch(NumberFormatException e){result.setText("Invalid amount");JOptionPane.showMessageDialog(this,"Invalid amount","Error",JOptionPane.ERROR_MESSAGE);}}
 public static void main(String[]args){SwingUtilities.invokeLater(()->new Converter().setVisible(true));}
}
